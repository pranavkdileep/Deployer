'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { LayoutDashboard, Code2, Rocket, Globe2, Link2, ArrowRightLeft, Shield, Database, WrenchIcon, HardDrive, Settings } from 'lucide-react'
import { cn } from '@/lib/utils'

interface SidePanelProps {
  isMobile?: boolean
  onClose?: () => void
}

const menuItems = [
  { name: 'Overview', icon: LayoutDashboard, href: '/overview' },
  { name: 'Source', icon: Code2, href: '/source' },
  { name: 'Deployments', icon: Rocket, href: '/deployments' },
  { name: 'Environment', icon: Globe2, href: '/environment' },
  { name: 'Domains', icon: Link2, href: '/domains' },
  { name: 'Redirects', icon: ArrowRightLeft, href: '/redirects' },
  { name: 'Security', icon: Shield, href: '/security' },
  { name: 'Resources', icon: Database, href: '/resources' },
  { name: 'Maintenance', icon: WrenchIcon, href: '/maintenance' },
  { name: 'Storage', icon: HardDrive, href: '/storage' },
  { name: 'Advanced', icon: Settings, href: '/advanced' },
]

export function SidePanel({ isMobile, onClose }: SidePanelProps) {
  const pathname = usePathname()

  return (
    <div className={cn(
      "bg-white shadow-sm border-r p-4",
      isMobile ? "w-full" : "hidden md:block w-64"
    )}>
      <nav className="space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href
          
          return (
            <Link
              key={item.name}
              href={item.href}
              onClick={isMobile ? onClose : undefined}
              className={cn(
                "flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors",
                isActive
                  ? "bg-blue-50 text-blue-600"
                  : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
              )}
            >
              <Icon className={cn(
                "mr-3 h-5 w-5 flex-shrink-0",
                isActive ? "text-blue-600" : "text-gray-400"
              )} />
              {item.name}
            </Link>
          )
        })}
      </nav>
    </div>
  )
}

