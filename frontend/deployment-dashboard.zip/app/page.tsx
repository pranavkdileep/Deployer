"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { CpuIcon, HardDriveIcon, NetworkIcon, PlayCircle, StopCircle, RefreshCw, Hammer, Trash2 } from 'lucide-react'
import { SidePanel } from './components/side-panel'
import { MobileNav } from './components/mobile-nav'
import { useState } from 'react'
import { RefreshCcw, Maximize2, Minimize2 } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useToast } from "@/components/ui/use-toast"

export default function Dashboard() {
  const [isExpanded, setIsExpanded] = useState(false)
  const { toast } = useToast()

  const handleAction = (action: string) => {
    // Simulate an API call
    setTimeout(() => {
      if (Math.random() > 0.5) {
        toast({
          title: "Success",
          description: `${action} action completed successfully.`,
          variant: "default",
        })
      } else {
        toast({
          title: "Error",
          description: `Failed to complete ${action} action. Please try again.`,
          variant: "destructive",
        })
      }
    }, 1000)
  }

  return (
    <div className="flex min-h-screen bg-gray-100">
      <SidePanel />
      
      <div className="flex-1">
        <header className="sticky top-0 z-10 bg-white shadow-sm border-b">
          <div className="flex items-center h-16 px-4">
            <MobileNav />
            <h1 className="text-xl font-semibold text-gray-900 md:text-2xl px-2">Deployment Dashboard</h1>
          </div>
        </header>

        <main className="p-4 md:p-8 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">CPU Usage</CardTitle>
                <CpuIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">45%</div>
                <p className="text-xs text-muted-foreground">+0.2% from last hour</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">RAM Usage</CardTitle>
                <HardDriveIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">60%</div>
                <p className="text-xs text-muted-foreground">+5% from last hour</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Network In</CardTitle>
                <NetworkIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">1.2 MB/s</div>
                <p className="text-xs text-muted-foreground">+0.1 MB/s from last hour</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Network Out</CardTitle>
                <NetworkIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">0.8 MB/s</div>
                <p className="text-xs text-muted-foreground">-0.2 MB/s from last hour</p>
              </CardContent>
            </Card>
          </div>

          <div className="flex flex-wrap gap-2 md:gap-4">
            <Button 
              className="flex items-center flex-1 sm:flex-none justify-center transition-all duration-200 ease-in-out hover:scale-105 active:scale-95"
              onClick={() => handleAction("Deploy")}
            >
              <PlayCircle className="mr-2 h-4 w-4" /> Deploy
            </Button>
            <Button 
              variant="secondary" 
              className="flex items-center flex-1 sm:flex-none justify-center transition-all duration-200 ease-in-out hover:scale-105 active:scale-95 hover:bg-gray-200"
              onClick={() => handleAction("Stop")}
            >
              <StopCircle className="mr-2 h-4 w-4" /> Stop
            </Button>
            <Button 
              variant="secondary" 
              className="flex items-center flex-1 sm:flex-none justify-center transition-all duration-200 ease-in-out hover:scale-105 active:scale-95 hover:bg-gray-200"
              onClick={() => handleAction("Restart")}
            >
              <RefreshCw className="mr-2 h-4 w-4" /> Restart
            </Button>
            <Button 
              variant="secondary" 
              className="flex items-center flex-1 sm:flex-none justify-center transition-all duration-200 ease-in-out hover:scale-105 active:scale-95 hover:bg-gray-200"
              onClick={() => handleAction("Force Rebuild")}
            >
              <Hammer className="mr-2 h-4 w-4" /> Force Rebuild
            </Button>
            <Button 
              variant="destructive" 
              className="flex items-center flex-1 sm:flex-none justify-center transition-all duration-200 ease-in-out hover:scale-105 active:scale-95"
              onClick={() => handleAction("Delete")}
            >
              <Trash2 className="mr-2 h-4 w-4" /> Delete
            </Button>
          </div>

          <Card className={cn(isExpanded && "fixed inset-4 z-50")}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle>Logs</CardTitle>
              <div className="flex space-x-2">
                <Button
                  variant="ghost"
                  size="icon"
                  className="transition-all duration-200 ease-in-out hover:scale-110 active:scale-95"
                  onClick={() => {
                    // Here you would typically fetch new logs
                    console.log("Reloading logs...")
                    toast({
                      title: "Logs Reloaded",
                      description: "The logs have been refreshed.",
                      variant: "default",
                    })
                  }}
                >
                  <RefreshCcw className="h-4 w-4" />
                  <span className="sr-only">Reload logs</span>
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="transition-all duration-200 ease-in-out hover:scale-110 active:scale-95"
                  onClick={() => setIsExpanded(!isExpanded)}
                >
                  {isExpanded ? (
                    <Minimize2 className="h-4 w-4" />
                  ) : (
                    <Maximize2 className="h-4 w-4" />
                  )}
                  <span className="sr-only">
                    {isExpanded ? "Minimize logs" : "Expand logs"}
                  </span>
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <ScrollArea className={cn(
                "w-full rounded-md border p-4",
                isExpanded ? "h-[calc(100vh-8rem)]" : "h-[200px] md:h-[400px]"
              )}>
                <div className="space-y-2">
                  <div className="font-mono text-xs md:text-sm">2023-05-01 10:00:00 - Application started</div>
                  <div className="font-mono text-xs md:text-sm">2023-05-01 10:01:23 - User authentication successful</div>
                  <div className="font-mono text-xs md:text-sm">2023-05-01 10:02:45 - Database connection established</div>
                  <div className="font-mono text-xs md:text-sm">2023-05-01 10:03:12 - API request received: GET /users</div>
                  <div className="font-mono text-xs md:text-sm">2023-05-01 10:03:15 - API response sent: 200 OK</div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  )
}

