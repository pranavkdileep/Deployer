'use client'

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CpuIcon, HardDriveIcon, NetworkIcon, PlayCircle, StopCircle, RefreshCw, Hammer, Trash2 } from 'lucide-react'
import Link from 'next/link'

export default function Dashboard() {
  const [logs, setLogs] = useState<string[]>([
    "2023-05-01 10:00:00 - Application started",
    "2023-05-01 10:01:23 - User authentication successful",
    "2023-05-01 10:02:45 - Database connection established",
    "2023-05-01 10:03:12 - API request received: GET /users",
    "2023-05-01 10:03:15 - API response sent: 200 OK",
    // Add more log entries as needed
  ])

  const [cpuUsage, setCpuUsage] = useState(45)
  const [ramUsage, setRamUsage] = useState(60)
  const [networkIn, setNetworkIn] = useState(1.2)
  const [networkOut, setNetworkOut] = useState(0.8)

  const handleAction = (action: string) => {
    setLogs(prev => [`${new Date().toISOString()} - ${action} action triggered`, ...prev])
  }

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Side Panel */}
      <div className="w-64 bg-white shadow-md">
        <div className="p-4">
          <h2 className="text-xl font-bold mb-4">Project Name</h2>
          <nav>
            <Link href="#" className="block py-2 text-blue-600 hover:underline">Source</Link>
            <Link href="#" className="block py-2 text-blue-600 hover:underline">Deployments</Link>
            <Link href="#" className="block py-2 text-blue-600 hover:underline">Environments</Link>
            <Link href="#" className="block py-2 text-blue-600 hover:underline">Domains</Link>
            <Link href="#" className="block py-2 text-blue-600 hover:underline">Storage</Link>
            <Link href="#" className="block py-2 text-blue-600 hover:underline">Advanced</Link>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8">
        <h1 className="text-2xl font-bold mb-6">Deployment Dashboard</h1>

        {/* Action Buttons */}
        <div className="mb-6 flex flex-wrap gap-4">
          <Button onClick={() => handleAction('Deploy')} className="flex items-center">
            <PlayCircle className="mr-2 h-4 w-4" /> Deploy
          </Button>
          <Button onClick={() => handleAction('Stop')} variant="secondary" className="flex items-center">
            <StopCircle className="mr-2 h-4 w-4" /> Stop
          </Button>
          <Button onClick={() => handleAction('Restart')} variant="secondary" className="flex items-center">
            <RefreshCw className="mr-2 h-4 w-4" /> Restart
          </Button>
          <Button onClick={() => handleAction('Force Rebuild')} variant="secondary" className="flex items-center">
            <Hammer className="mr-2 h-4 w-4" /> Force Rebuild
          </Button>
          <Button onClick={() => handleAction('Delete')} variant="destructive" className="flex items-center">
            <Trash2 className="mr-2 h-4 w-4" /> Delete
          </Button>
        </div>

        {/* System Utilization */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">CPU Usage</CardTitle>
              <CpuIcon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{cpuUsage}%</div>
              <p className="text-xs text-muted-foreground">+0.2% from last hour</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">RAM Usage</CardTitle>
              <HardDriveIcon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{ramUsage}%</div>
              <p className="text-xs text-muted-foreground">+5% from last hour</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Network In</CardTitle>
              <NetworkIcon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{networkIn} MB/s</div>
              <p className="text-xs text-muted-foreground">+0.1 MB/s from last hour</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Network Out</CardTitle>
              <NetworkIcon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{networkOut} MB/s</div>
              <p className="text-xs text-muted-foreground">-0.2 MB/s from last hour</p>
            </CardContent>
          </Card>
        </div>

        {/* Logs */}
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Logs</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px] w-full rounded-md border p-4">
              {logs.map((log, index) => (
                <div key={index} className="mb-2">
                  <code className="text-sm">{log}</code>
                </div>
              ))}
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

