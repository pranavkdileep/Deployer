from flask import Flask
import os

app = Flask(__name__)

#api key from env
apikey=os.environ.get('API_KEY')
apisec=os.environ.get('API_SEC')

@app.route('/')
def hello_world():
    return f'API_KEY {apikey}<br>API_SEC {apisec}'

if __name__ == '__main__':
    app.run()